package com.fakkarny.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF17233B)
private val Teal = Color(0xFF12A89D)
private val Bg = Color(0xFFF4F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        setContent { FakkarnyScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FakkarnyScreen() {
    val context = LocalContext.current
    var reminders by remember { mutableStateOf(ReminderStore.all(context)) }
    var showDialog by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var selectedTime by remember { mutableLongStateOf(System.currentTimeMillis() + 60 * 60 * 1000) }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) note = spoken
    }
    fun refresh() { reminders = ReminderStore.all(context) }
    fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "اتكلم واكتب التذكير")
        }
        runCatching { speech.launch(intent) }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("فكّرني", color = Ink, fontWeight = FontWeight.Bold)
                            Text("كل حاجة في وقتها", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Bg)
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { note = ""; selectedTime = System.currentTimeMillis() + 3600000; showDialog = true },
                    containerColor = Teal, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة تذكير")
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 18.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Ink)
                ) {
                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("خلي بالك من المهم", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("اكتب أو اتكلم… وإحنا نفكّرك", color = Color(0xFFD5E1EE))
                        }
                        Icon(Icons.Default.NotificationsActive, null, tint = Color(0xFF62D8CC), modifier = Modifier.size(42.dp))
                    }
                }
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("تذكيراتك", color = Ink, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${reminders.count { !it.done }} متبقي", color = Teal, fontWeight = FontWeight.SemiBold)
                }
                if (reminders.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.NotificationsActive, null, tint = Color.LightGray, modifier = Modifier.size(56.dp))
                            Spacer(Modifier.height(10.dp))
                            Text("لسه مفيش تذكيرات", color = Color.Gray, fontWeight = FontWeight.Medium)
                            Text("اضغط + وأضف أول تذكير", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                        items(reminders, key = { it.id }) { item ->
                            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.text, color = if (item.done) Color.Gray else Ink, fontWeight = FontWeight.SemiBold)
                                        Spacer(Modifier.height(5.dp))
                                        Text(SimpleDateFormat("EEEE، d MMM - hh:mm a", Locale("ar")).format(Date(item.time)),
                                            color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                                    }
                                    IconButton(onClick = {
                                        ReminderScheduler.cancel(context, item.id)
                                        ReminderStore.upsert(context, item.copy(done = !item.done))
                                        refresh()
                                    }) {
                                        Icon(if (item.done) Icons.Default.Check else Icons.Default.Check, null, tint = Teal)
                                    }
                                    IconButton(onClick = { ReminderScheduler.cancel(context, item.id); ReminderStore.remove(context, item.id); refresh() }) {
                                        Icon(Icons.Default.Delete, null, tint = Color(0xFFE16B6B))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("تذكير جديد", color = Ink, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("هفكّرك بإيه؟") },
                            placeholder = { Text("مثلاً: اتصل بأحمد") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedButton(onClick = { startVoice() }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Mic, null, tint = Teal)
                            Spacer(Modifier.width(8.dp))
                            Text("سجّل التذكير بصوتك")
                        }
                        val cal = Calendar.getInstance().apply { timeInMillis = selectedTime }
                        OutlinedButton(onClick = {
                            DatePickerDialog(context, { _, y, m, d ->
                                val c = Calendar.getInstance().apply { timeInMillis = selectedTime; set(y, m, d) }
                                selectedTime = c.timeInMillis
                            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                        }, modifier = Modifier.fillMaxWidth()) { Text("التاريخ: " + SimpleDateFormat("d MMM yyyy", Locale("ar")).format(Date(selectedTime))) }
                        OutlinedButton(onClick = {
                            val c = Calendar.getInstance().apply { timeInMillis = selectedTime }
                            TimePickerDialog(context, { _, h, min ->
                                val updated = Calendar.getInstance().apply { timeInMillis = selectedTime; set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0) }
                                selectedTime = updated.timeInMillis
                            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
                        }, modifier = Modifier.fillMaxWidth()) { Text("الوقت: " + SimpleDateFormat("hh:mm a", Locale("ar")).format(Date(selectedTime))) }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (note.isNotBlank() && selectedTime > System.currentTimeMillis()) {
                            val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
                            val reminder = Reminder(id, note.trim(), selectedTime)
                            ReminderStore.upsert(context, reminder)
                            ReminderScheduler.schedule(context, reminder)
                            refresh()
                            showDialog = false
                        }
                    }) { Text("احفظ التذكير", color = Teal, fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { showDialog = false }) { Text("إلغاء") } }
            )
        }
    }
}
