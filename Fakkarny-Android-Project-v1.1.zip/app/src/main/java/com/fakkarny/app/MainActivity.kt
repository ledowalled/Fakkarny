package com.fakkarny.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF17233B)
private val Teal = Color(0xFF12A89D)
private val Bg = Color(0xFFF4F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        setContent { FakkarnyScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FakkarnyScreen() {
    val context = LocalContext.current
    var reminders by remember { mutableStateOf(ReminderStore.all(context)) }
    var showDialog by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var messageIsError by remember { mutableStateOf(false) }

    fun refresh() { reminders = ReminderStore.all(context) }
    fun parseAndSave(raw: String) {
        when (val parsed = NaturalReminderParser.parse(raw)) {
            is ReminderParseResult.Success -> {
                val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
                val reminder = Reminder(id, parsed.task, parsed.timeMillis)
                ReminderStore.upsert(context, reminder)
                ReminderScheduler.schedule(context, reminder)
                refresh()
                note = ""
                showDialog = false
                message = "تم حفظ: ${parsed.task} — ${SimpleDateFormat("EEEE d MMM، hh:mm a", Locale("ar")).format(Date(parsed.timeMillis))}"
                messageIsError = false
            }
            is ReminderParseResult.NeedsClarification -> {
                message = parsed.message
                messageIsError = true
            }
        }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            note = spoken
            parseAndSave(spoken)
        }
    }
    fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "قول التذكير والموعد، مثال: فكرني بكرة الساعة 5 مساءً أكلم أحمد")
        }
        runCatching { speech.launch(intent) }.onFailure {
            message = "خاصية تحويل الصوت لنص غير متاحة على الجهاز حاليًا"
            messageIsError = true
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                CenterAlignedTopAppBar(title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("فكّرني", color = Ink, fontWeight = FontWeight.Bold)
                        Text("كل حاجة في وقتها", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                }, colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Bg))
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { note = ""; message = ""; showDialog = true }, containerColor = Teal, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة تذكير")
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Card(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 18.dp), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Ink)) {
                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("خلي بالك من المهم", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("اتكلم أو اكتب جملة فيها المهمة والموعد", color = Color(0xFFD5E1EE))
                        }
                        Icon(Icons.Default.NotificationsActive, null, tint = Color(0xFF62D8CC), modifier = Modifier.size(42.dp))
                    }
                }
                if (message.isNotBlank()) {
                    Text(message, color = if (messageIsError) Color(0xFFB54747) else Teal, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(bottom = 12.dp))
                }
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("تذكيراتك", color = Ink, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${reminders.count { !it.done }} متبقي", color = Teal, fontWeight = FontWeight.SemiBold)
                }
                if (reminders.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.NotificationsActive, null, tint = Color.LightGray, modifier = Modifier.size(56.dp))
                            Spacer(Modifier.height(10.dp))
                            Text("لسه مفيش تذكيرات", color = Color.Gray, fontWeight = FontWeight.Medium)
                            Text("اضغط + واتكلم أو اكتب موعدك", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                        items(reminders, key = { it.id }) { item ->
                            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.text, color = if (item.done) Color.Gray else Ink, fontWeight = FontWeight.SemiBold)
                                        Spacer(Modifier.height(5.dp))
                                        Text(SimpleDateFormat("EEEE، d MMM - hh:mm a", Locale("ar")).format(Date(item.time)), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                                    }
                                    IconButton(onClick = {
                                        if (!item.done && item.time > System.currentTimeMillis()) ReminderScheduler.cancel(context, item.id)
                                        val updated = item.copy(done = !item.done)
                                        ReminderStore.upsert(context, updated)
                                        if (!updated.done && updated.time > System.currentTimeMillis()) ReminderScheduler.schedule(context, updated)
                                        refresh()
                                    }) { Icon(Icons.Default.Check, null, tint = Teal) }
                                    IconButton(onClick = { ReminderScheduler.cancel(context, item.id); ReminderStore.remove(context, item.id); refresh() }) {
                                        Icon(Icons.Default.Delete, null, tint = Color(0xFFE16B6B))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("تذكير جديد", color = Ink, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("اكتب التذكير والموعد في جملة واحدة") },
                            placeholder = { Text("فكرني بكرة الساعة 5 مساءً أروح للدكتور") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedButton(onClick = { startVoice() }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Mic, null, tint = Teal); Spacer(Modifier.width(8.dp)); Text("اتكلم وسجّل التذكير")
                        }
                        Text("التطبيق هيستخرج التاريخ والساعة ويحفظ التذكير تلقائيًا. لو الموعد مش واضح هيطلب منك توضيح بدل ما يحدد موعد غلط.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        if (messageIsError && message.isNotBlank()) Text(message, color = Color(0xFFB54747), style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { parseAndSave(note) }) { Text("حلّل واحفظ تلقائيًا", color = Teal, fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { showDialog = false }) { Text("إلغاء") } }
            )
        }
    }
}
