package com.fakkarny.app

import java.text.Normalizer
import java.util.Calendar
import java.util.Locale

sealed class ReminderParseResult {
    data class Success(val task: String, val timeMillis: Long) : ReminderParseResult()
    data class NeedsClarification(val message: String) : ReminderParseResult()
}

object NaturalReminderParser {
    private val months = mapOf(
        "يناير" to Calendar.JANUARY, "فبراير" to Calendar.FEBRUARY, "مارس" to Calendar.MARCH,
        "ابريل" to Calendar.APRIL, "أبريل" to Calendar.APRIL, "مايو" to Calendar.MAY,
        "يونيو" to Calendar.JUNE, "يوليو" to Calendar.JULY, "اغسطس" to Calendar.AUGUST,
        "أغسطس" to Calendar.AUGUST, "سبتمبر" to Calendar.SEPTEMBER, "اكتوبر" to Calendar.OCTOBER,
        "أكتوبر" to Calendar.OCTOBER, "نوفمبر" to Calendar.NOVEMBER, "ديسمبر" to Calendar.DECEMBER
    )
    private val weekdays = mapOf(
        "الاحد" to Calendar.SUNDAY, "الأحد" to Calendar.SUNDAY,
        "الاتنين" to Calendar.MONDAY, "الإثنين" to Calendar.MONDAY, "الاثنين" to Calendar.MONDAY,
        "الثلاثاء" to Calendar.TUESDAY, "التلات" to Calendar.TUESDAY, "التلاتاء" to Calendar.TUESDAY,
        "الاربعاء" to Calendar.WEDNESDAY, "الأربعاء" to Calendar.WEDNESDAY,
        "الخميس" to Calendar.THURSDAY, "الجمعه" to Calendar.FRIDAY, "الجمعة" to Calendar.FRIDAY,
        "السبت" to Calendar.SATURDAY
    )

    fun parse(raw: String, nowMillis: Long = System.currentTimeMillis()): ReminderParseResult {
        var s = normalize(raw)
        s = s.replace(Regex("^(فكرني|فكرنى|ذكرني|ذكّرني|عايزك تفكرني|عاوزك تفكرني)\\s*"), "")
        val c = Calendar.getInstance().apply { timeInMillis = nowMillis; set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        var dateFound = false
        var timeFound = false

        // Relative duration: بعد ساعتين، بعد ساعة ونصف، بعد 30 دقيقة، بعد ربع ساعة
        val relative = Regex("بعد\\s+(نص ساعه|نصف ساعه|ربع ساعه|ساعه ونص|ساعه ونصف|ساعه|ساعتين|ثلاث ساعات|\\d+\\s*(?:ساعه|ساعات|دقيقه|دقائق))")
        val rel = relative.find(s)
        if (rel != null) {
            val phrase = rel.value
            val mins = when {
                phrase.contains("نص") || phrase.contains("نصف") -> 30
                phrase.contains("ربع") -> 15
                phrase.contains("ساعتين") -> 120
                phrase.contains("ثلاث") -> 180
                phrase.contains("ونص") || phrase.contains("ونصف") -> 90
                else -> {
                    val n = Regex("\\d+").find(phrase)?.value?.toIntOrNull() ?: 1
                    if (phrase.contains("دقيق")) n else n * 60
                }
            }
            c.add(Calendar.MINUTE, mins)
            dateFound = true; timeFound = true
            s = s.replaceRange(rel.range, " ")
        } else {
            when {
                Regex("بعد بكره|بعد بكرة").containsMatchIn(s) -> { c.add(Calendar.DAY_OF_MONTH, 2); dateFound = true; s = s.replace(Regex("بعد بكره|بعد بكرة"), " ") }
                Regex("بكره|بكرة|غدا|غداً").containsMatchIn(s) -> { c.add(Calendar.DAY_OF_MONTH, 1); dateFound = true; s = s.replace(Regex("بكره|بكرة|غدا|غداً"), " ") }
                Regex("النهارده|النهاردة|اليوم").containsMatchIn(s) -> { dateFound = true; s = s.replace(Regex("النهارده|النهاردة|اليوم"), " ") }
            }
            val weekdayEntry = weekdays.entries.firstOrNull { Regex("(?:يوم\\s+)?${Regex.escape(normalize(it.key))}").containsMatchIn(s) }
            if (weekdayEntry != null) {
                val target = weekdayEntry.value
                var delta = (target - c.get(Calendar.DAY_OF_WEEK) + 7) % 7
                if (delta == 0) delta = 7
                c.add(Calendar.DAY_OF_MONTH, delta)
                dateFound = true
                s = s.replace(Regex("يوم\\s+${Regex.escape(normalize(weekdayEntry.key))}|${Regex.escape(normalize(weekdayEntry.key))}"), " ")
            }
            val numericDate = Regex("(?:يوم\\s+)?(\\d{1,2})\\s+(يناير|فبراير|مارس|ابريل|أبريل|مايو|يونيو|يوليو|اغسطس|أغسطس|سبتمبر|اكتوبر|أكتوبر|نوفمبر|ديسمبر)(?:\\s+(\\d{4}))?").find(s)
            if (numericDate != null) {
                val day = numericDate.groupValues[1].toInt()
                val month = months[numericDate.groupValues[2]] ?: months[normalize(numericDate.groupValues[2])]
                if (month != null && day in 1..31) {
                    var year = numericDate.groupValues[3].toIntOrNull() ?: c.get(Calendar.YEAR)
                    c.set(year, month, day)
                    if (numericDate.groupValues[3].isBlank() && c.timeInMillis <= nowMillis) c.add(Calendar.YEAR, 1)
                    dateFound = true
                }
                s = s.replaceRange(numericDate.range, " ")
            }
        }

        val timeRegex = Regex("(?:الساعه\\s*)?(\\d{1,2})(?::(\\d{2}))?\\s*(صباحا|الصبح|صبح|مساء|مساءا|بالليل|ليل|الظهر|العصر|م|ص)?")
        val timeMatch = timeRegex.find(s)
        if (timeMatch != null) {
            var hour = timeMatch.groupValues[1].toIntOrNull() ?: -1
            val minute = timeMatch.groupValues[2].toIntOrNull() ?: 0
            val marker = timeMatch.groupValues[3]
            if (hour in 0..23 && minute in 0..59) {
                when (marker) {
                    "صباحا", "الصبح", "صبح", "ص" -> if (hour == 12) hour = 0
                    "مساء", "مساءا", "بالليل", "ليل", "م", "الظهر", "العصر" -> if (hour in 1..11) hour += 12
                    else -> if (hour in 1..11) return ReminderParseResult.NeedsClarification("حدّد صباحًا ولا مساءً للساعة $hour")
                }
                c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute)
                timeFound = true
                s = s.replaceRange(timeMatch.range, " ")
            }
        }
        if (!dateFound || !timeFound) return ReminderParseResult.NeedsClarification("مش قادر أحدد التاريخ والساعة بدقة. اكتب مثلًا: فكرني بكرة الساعة 5 مساءً أكلم أحمد")
        if (c.timeInMillis <= nowMillis) return ReminderParseResult.NeedsClarification("الموعد اللي فهمته فات بالفعل. اكتب تاريخ ووقت مستقبليين")

        val task = s.replace(Regex("\\s+"), " ").trim().trim('،', ',', '.', '؛', ';', ':')
            .replace(Regex("^(اني|إنّي|اني)\\s*"), "").trim()
        if (task.isBlank()) return ReminderParseResult.NeedsClarification("فهمت الموعد، لكن محتاج أعرف هفكّرك بإيه")
        return ReminderParseResult.Success(task, c.timeInMillis)
    }

    private fun normalize(input: String): String {
        val digits = input.map { ch -> when (ch) {
            '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'; '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'; else -> ch
        } }.joinToString("")
        return Normalizer.normalize(digits, Normalizer.Form.NFC)
            .lowercase(Locale("ar", "EG"))
            .replace("إ", "ا").replace("أ", "ا").replace("آ", "ا")
            .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
    }
}
