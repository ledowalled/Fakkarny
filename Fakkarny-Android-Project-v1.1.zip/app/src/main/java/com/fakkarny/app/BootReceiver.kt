package com.fakkarny.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            ReminderStore.all(context).filter { !it.done && it.time > System.currentTimeMillis() }
                .forEach { ReminderScheduler.schedule(context, it) }
        }
    }
}
