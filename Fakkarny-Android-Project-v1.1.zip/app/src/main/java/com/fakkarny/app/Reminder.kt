package com.fakkarny.app

data class Reminder(
    val id: Int,
    val text: String,
    val time: Long,
    val done: Boolean = false
)
