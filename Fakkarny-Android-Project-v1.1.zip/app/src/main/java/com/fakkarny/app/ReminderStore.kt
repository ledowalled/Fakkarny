package com.fakkarny.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ReminderStore {
    private const val PREFS = "fakkarny_data"
    private const val KEY = "reminders"

    fun all(context: Context): List<Reminder> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).mapNotNull { i ->
            runCatching {
                val o = arr.getJSONObject(i)
                Reminder(o.getInt("id"), o.getString("text"), o.getLong("time"), o.optBoolean("done"))
            }.getOrNull()
        }.sortedWith(compareBy<Reminder> { it.done }.thenBy { it.time })
    }

    fun save(context: Context, items: List<Reminder>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().put("id", it.id).put("text", it.text).put("time", it.time).put("done", it.done))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun upsert(context: Context, reminder: Reminder) {
        val items = all(context).filterNot { it.id == reminder.id } + reminder
        save(context, items)
    }

    fun remove(context: Context, id: Int) = save(context, all(context).filterNot { it.id == id })
}
