package com.fakkarny.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class VoiceReminderService : Service(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var message: String = "عندك تذكير"
    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        message = intent?.getStringExtra("text") ?: "عندك تذكير"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("voice_service", "الصوت", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification: Notification = android.app.Notification.Builder(this, "voice_service")
            .setContentTitle("فكّرني")
            .setContentText("جاري قراءة التذكير")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(pending)
            .build()
        startForeground(9001, notification)
        return START_NOT_STICKY
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ar")
            tts?.setSpeechRate(0.92f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            })
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "fakkarny_reminder")
        } else {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }
    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
